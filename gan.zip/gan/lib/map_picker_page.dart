// lib/map_picker_page.dart

import 'package:flutter/material.dart';
// Note: keep this file minimal and dependency-free so analyzer/package resolution
// issues don't block the build. If you need geolocation or HTTP reverse-geocoding,
// add the packages to pubspec.yaml and reintroduce imports.

class MapPickerPage extends StatefulWidget {
  const MapPickerPage({Key? key}) : super(key: key);

  @override
  State<MapPickerPage> createState() => _MapPickerPageState();
}

class _MapPickerPageState extends State<MapPickerPage> {
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _latController = TextEditingController();
  final TextEditingController _lngController = TextEditingController();

  void _confirm() {
    final address = _addressController.text.trim();
    final lat = double.tryParse(_latController.text.trim());
    final lng = double.tryParse(_lngController.text.trim());

    if (address.isEmpty && (lat == null || lng == null)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi alamat atau koordinat')));
      return;
    }

    Navigator.pop(context, {
      'address': address,
      'lat': lat,
      'lng': lng,
    });
  }

  @override
  void dispose() {
    _addressController.dispose();
    _latController.dispose();
    _lngController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pilih Lokasi')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: _addressController, decoration: const InputDecoration(labelText: 'Alamat (opsional)')),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: _latController, decoration: const InputDecoration(labelText: 'Latitude'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: _lngController, decoration: const InputDecoration(labelText: 'Longitude'))),
            ]),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _confirm, child: const Text('Pilih Lokasi Ini')),
          ],
        ),
      ),
    );
  }
}