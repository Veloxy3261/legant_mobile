// lib/cart_screen.dart

import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart'; 
import 'models/cart_item.dart'; 
import 'checkout_page.dart'; 

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> with AutomaticKeepAliveClientMixin {
  late Future<List<CartItem>> _cartItemsFuture;
  List<CartItem> _cartItems = [];
  String _userId = '';
  // Timer for periodic auto-refresh
  Timer? _autoRefreshTimer;

  final String _getCartUrl = 'https://coloria.biz.id/api/get_cart.php';
  final String _removeCartUrl = 'https://coloria.biz.id/api/remove_from_cart.php';
  
  static const Color primaryColor = Colors.black;
  static const Color secondaryColor = Color(0xFF333333);
  static const Color accentColor = Color(0xFFFFD700);
  // Cache TTL in minutes. Change this to adjust staleness tolerance.
  static const int _cacheTTLMinutes = 10;

  @override
  void initState() {
    super.initState();
    _loadCachedCart();
    _loadUserIdAndFetchCart();
    // Start periodic auto-refresh every 30 seconds
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      // Only trigger a refresh if widget is still mounted
      if (mounted) {
        _refreshCart();
      }
    });
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    super.dispose();
  }

  // Load cached cart from SharedPreferences and show immediately
  Future<void> _loadCachedCart() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString('cached_cart');
      final ts = prefs.getInt('cached_cart_ts');
      if (cached != null && cached.isNotEmpty && ts != null) {
        final cacheTime = DateTime.fromMillisecondsSinceEpoch(ts);
        final age = DateTime.now().difference(cacheTime);
        if (age.inMinutes <= _cacheTTLMinutes) {
          final List<dynamic> decoded = jsonDecode(cached);
          final items = decoded.map((e) => CartItem.fromJson(e as Map<String, dynamic>)).toList();
          _updateCartState(items);
        } else {
          // Cache expired: remove keys
          await prefs.remove('cached_cart');
          await prefs.remove('cached_cart_ts');
        }
      }
    } catch (_) {
      // ignore cache load errors
    }
  }

  Future<void> _saveCachedCart(List<CartItem> items) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final encoded = jsonEncode(items.map((i) => {
            'cart_id': i.cartId,
            'helm_id': i.helmId,
            'nama_helm': i.namaHelm,
            'harga': i.harga,
            'gambar': i.gambar,
            'quantity': i.quantity,
          }).toList());
  await prefs.setString('cached_cart', encoded);
  await prefs.setInt('cached_cart_ts', DateTime.now().millisecondsSinceEpoch);
    } catch (_) {
      // ignore cache save errors
    }
  }

  Future<void> _refreshCart() async {
    if (!mounted) return;
    setState(() {
      _cartItemsFuture = _fetchCartItems();
    });
    try {
      await _cartItemsFuture;
    } catch (_) {
      // ignore errors here; FutureBuilder will show errors
    }
  }

  // Helper untuk memastikan user_id ada sebelum fetch
  Future<void> _loadUserIdAndFetchCart() async {
    final prefs = await SharedPreferences.getInstance();
    _userId = prefs.getString('userId') ?? '';
    setState(() {
      _cartItemsFuture = _fetchCartItems();
    });
  }

  Future<List<CartItem>> _fetchCartItems() async {
    if (_userId.isEmpty) {
      // Tidak perlu throw error, cukup kembalikan list kosong
      return []; 
    }

    try {
      final response = await http.post(
        Uri.parse(_getCartUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': _userId}),
      );

      final responseData = jsonDecode(response.body);

      if (responseData['status'] == 'success') {
        List<dynamic> dataList = responseData['data'];
        final items = dataList.map((json) => CartItem.fromJson(json)).toList();
  _updateCartState(items); 
  _saveCachedCart(items);
        return items;
      } else {
        _updateCartState([]); 
        throw Exception(responseData['message'] ?? 'Gagal memuat keranjang');
      }
    } catch (e) {
      _updateCartState([]); 
      throw Exception('Error: ${e.toString()}');
    }
  }

  Future<void> _removeFromCart(String cartId) async {
    try {
      final response = await http.post(
        Uri.parse(_removeCartUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'cart_id': cartId,
          'user_id': _userId,
        }),
      );

      final responseData = jsonDecode(response.body);
      if (responseData['status'] == 'success') {
        _showMessage(responseData['message'] ?? 'Item dihapus');
        setState(() {
          _cartItemsFuture = _fetchCartItems();
        });
  // Update cache will be handled by _fetchCartItems when it completes
      } else {
        _showMessage(responseData['message'] ?? 'Gagal menghapus', isError: true);
      }
    } catch (e) {
      _showMessage('Error: ${e.toString()}', isError: true);
    }
  }

  void _updateCartState(List<CartItem> items) {
    if (mounted) {
      setState(() {
        _cartItems = items;
      });
    }
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.redAccent : Colors.green,
      ),
    );
  }
  
  double _calculateTotalPrice() {
    double total = 0.0;
    for (var item in _cartItems) {
      double harga = double.tryParse(item.harga.replaceAll('.', '')) ?? 0.0;
      total += harga * item.quantity;
    }
    return total;
  }
  
  String _formatRupiah(double amount) {
    final format = NumberFormat.currency(
      locale: 'id_ID', 
      symbol: 'Rp ', 
      decimalDigits: 0,
    );
    return format.format(amount);
  }

  @override
  Widget build(BuildContext context) {
  super.build(context);
    return Scaffold(
      backgroundColor: secondaryColor,
      // Hapus AppBar, karena AppBar sudah ada di home.dart
      // appBar: _buildAppBar(), 
      body: _buildBody(),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  // ... (Fungsi _buildAppBar() bisa dihapus) ...

  Widget _buildBody() {
    return RefreshIndicator(
      onRefresh: _refreshCart,
      child: FutureBuilder<List<CartItem>>(
        future: _cartItemsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator(color: accentColor));
          } else if (snapshot.hasError) {
            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                Center(
                    child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text('Error: ${snapshot.error}',
                      style: GoogleFonts.poppins(color: Colors.redAccent)),
                )),
              ],
            );
          } else if (_cartItems.isEmpty) {
            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                Center(
                    child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Text('Keranjang Anda kosong.',
                      style: GoogleFonts.poppins(color: Colors.white70)),
                )),
              ],
            );
          }
          return ListView.builder(
            itemCount: _cartItems.length,
            itemBuilder: (context, index) {
              final item = _cartItems[index];
              return _buildCartItemCard(item);
            },
          );
        },
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final double totalPrice = _calculateTotalPrice();

    return Container(
      color: primaryColor,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15)
          .copyWith(bottom: MediaQuery.of(context).padding.bottom + 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Total Harga:',
                style: GoogleFonts.poppins(color: Colors.white70, fontSize: 14),
              ),
              Text(
                _formatRupiah(totalPrice),
                style: GoogleFonts.poppins(
                    color: accentColor,
                    fontSize: 20,
                    fontWeight: FontWeight.w700),
              ),
            ],
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: accentColor,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
            ),
            
            // --- PERUBAHAN UTAMA DI SINI ---
            onPressed: _cartItems.isEmpty ? null : () async { 
              
              // 1. Navigasi ke Halaman Checkout dan kirim DATA LENGKAP
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CheckoutPage(
                    baseTotalPriceIDR: totalPrice,
                    cartItems: _cartItems, // Kirim list item
                    userId: _userId, // Kirim user_id
                  ),
                ),
              );

              // 2. Cek hasil saat kembali. Jika sukses, refresh keranjang
              if (result == 'checkout_success' && mounted) {
                setState(() {
                  _cartItemsFuture = _fetchCartItems(); // Panggil ulang API
                });
              }
            },
            child: Text(
              'Checkout',
              style: GoogleFonts.poppins(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCartItemCard(CartItem item) {
    // ... (Fungsi ini tidak berubah, salin dari kode Anda yang ada)
    final double itemPrice = double.tryParse(item.harga.replaceAll('.', '')) ?? 0.0;
    
    return Card(
      color: const Color(0xFF1A1A1A),
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Image.network(
                item.gambar,
                width: 70,
                height: 70,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Container(width: 70, height: 70, color: Colors.black, child: Icon(Icons.broken_image, color: Colors.grey)),
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.namaHelm,
                    style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 16),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    _formatRupiah(itemPrice),
                    style: GoogleFonts.poppins(
                        color: accentColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                  ),
                  Text(
                    'Jumlah: ${item.quantity}',
                    style: GoogleFonts.poppins(
                        color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () => _showDeleteConfirmation(item.cartId),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(String cartId) {
    // ... (Fungsi ini tidak berubah, salin dari kode Anda yang ada)
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: secondaryColor,
        title: Text('Hapus Item', style: GoogleFonts.poppins(color: Colors.white)),
        content: Text('Anda yakin ingin menghapus item ini dari keranjang?', style: GoogleFonts.poppins(color: Colors.white70)),
        actions: [
          TextButton(
            child: Text('Batal', style: GoogleFonts.poppins(color: Colors.white70)),
            onPressed: () => Navigator.of(ctx).pop(),
          ),
          TextButton(
            child: Text('Hapus', style: GoogleFonts.poppins(color: Colors.redAccent)),
            onPressed: () {
              Navigator.of(ctx).pop(); 
              _removeFromCart(cartId); 
            },
          ),
        ],
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}