// lib/product_card.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'models/helm.dart';
import 'product_detail.dart';

class ProductCard extends StatelessWidget {
  final Helm helm;
  final Color accentColor;

  const ProductCard({super.key, required this.helm, required this.accentColor});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigasi ke halaman detail dengan Hero Animation
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(helm: helm),
          ),
        );
      },
      child: Card(
        color: const Color(0xFF1A1A1A), // Latar belakang card hitam gelap
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side: BorderSide(color: accentColor.withOpacity(0.5), width: 1), // Border emas tipis
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                // Hero Animation untuk transisi gambar
        child: Hero(
                  tag: 'helm-image-${helm.id}', // Tag unik
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Image.network(
                      // Menggunakan headers sebagai solusi potensial untuk masalah gambar
                      helm.gambar,
          semanticLabel: helm.nama,
                      headers: const {'User-Agent': 'FlutterApp'}, 
                      fit: BoxFit.cover,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            color: accentColor,
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes!
                                : null,
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        // Jika gambar gagal dimuat (misalnya, URL rusak)
                        // Perhatikan: Gambar placeholder ini yang muncul saat ada masalah
                        return const Center(
                          child: Icon(Icons.broken_image, color: Colors.grey, size: 50),
                        );
                      }
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
              child: Text(
                helm.nama,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: Colors.white,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text(
                'Rp ${helm.harga is int ? helm.harga.toRupiah() : helm.harga.toString().toRupiah()}',
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                  color: accentColor,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Small helper extension to format integer prices as Indonesian Rupiah with thousands separators.
extension RupiahFormatString on String {
  String toRupiah() {
    // Remove non-digits
    final digits = replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return this;
    final buffer = StringBuffer();
    int count = 0;
    for (int i = digits.length - 1; i >= 0; i--) {
      buffer.write(digits[i]);
      count++;
      if (count == 3 && i != 0) {
        buffer.write('.');
        count = 0;
      }
    }
    return buffer.toString().split('').reversed.join();
  }
}

extension RupiahFormatInt on int {
  String toRupiah() => toString().toRupiah();
}