// lib/main.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'login.dart';

// 1. TAMBAHKAN IMPOR INI
import 'package:intl/date_symbol_data_local.dart';

// 2. UBAH main() MENJADI async dan TAMBAHKAN 2 BARIS INI
void main() async {
  // Baris ini wajib ada untuk memanggil kode native sebelum runApp
  WidgetsFlutterBinding.ensureInitialized();
  
  // Inisialisasi data lokal 'id_ID' untuk formatting tanggal
  await initializeDateFormatting('id_ID', null);
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Definisi Skema Warna
    const Color primaryColor = Colors.black;
    const Color secondaryColor = Color(0xFF333333); // Abu-abu gelap
    const Color accentColor = Color(0xFFFFD700); // Emas

    return MaterialApp(
      title: 'Legant Helmet Catalog',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Tema gelap yang elegan
        brightness: Brightness.dark,
        primaryColor: primaryColor,
        scaffoldBackgroundColor: secondaryColor,
        // Gunakan Poppins sebagai font default
        textTheme: GoogleFonts.poppinsTextTheme(
          Theme.of(context).textTheme.apply(
                bodyColor: Colors.white,
                displayColor: Colors.white,
              ),
        ),
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.grey,
          brightness: Brightness.dark,
          cardColor: secondaryColor,
        ).copyWith(
          secondary: accentColor, // Aksen Emas
        ),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}