// lib/home.dart

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models/helm.dart';
import 'product_card.dart';
import 'login.dart'; 
import 'user_profile_screen.dart'; 
import 'company_profile_screen.dart';
import 'cart_screen.dart'; 

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0; 
  static const Color accentColor = Color(0xFFFFD700); // Definisikan di sini

  // Daftar halaman
  // Kita perlu passing accentColor ke _KatalogPage
  static final List<Widget> _widgetOptions = <Widget>[
    _KatalogPage(accentColor: accentColor), // Halaman Katalog
    CartScreen(),   // Halaman Keranjang
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _handleLogout() {
    // Clear cached cart on logout
    () async {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('cached_cart');
        await prefs.remove('cached_cart_ts');
      } catch (_) {
        // ignore
      }
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const LoginPage()),
        (Route<dynamic> route) => false,
      );
    }();
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Colors.black;
    const Color secondaryColor = Color(0xFF333333);

    return Scaffold(
      backgroundColor: secondaryColor,
      appBar: AppBar(
        title: Text(
          _selectedIndex == 0 ? 'Legant Helmet Catalog' : 'Keranjang Saya',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700,
            color: accentColor,
          ),
        ),
        backgroundColor: primaryColor,
        iconTheme: const IconThemeData(color: accentColor),
      ),
      
      // DRAWER (Tidak berubah)
      drawer: Drawer(
        backgroundColor: primaryColor,
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: secondaryColor,
              ),
              child: Text(
                'Menu Legant',
                style: GoogleFonts.poppins(
                  color: accentColor,
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.white),
              title: Text(
                'Profile User',
                style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const UserProfileScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.info_outline, color: Colors.white),
              title: Text(
                'About Legant',
                style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CompanyProfileScreen()),
                );
              },
            ),
            const Divider(color: Color(0xFF1A1A1A), height: 30, thickness: 2),
            ListTile(
              leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
              title: Text(
                'Logout',
                style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 16, fontWeight: FontWeight.w600),
              ),
              onTap: _handleLogout,
            ),
          ],
        ),
      ),

      body: IndexedStack(
        index: _selectedIndex,
        children: _widgetOptions,
      ),

      // BOTTOM NAVIGATION BAR (Tidak berubah)
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Keranjang',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        backgroundColor: primaryColor,
        selectedItemColor: accentColor,
        unselectedItemColor: Colors.grey,
        selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.poppins(),
      ),
    );
  }
}

// --- PERUBAHAN UTAMA ADA DI SINI ---

class _KatalogPage extends StatefulWidget {
  final Color accentColor;
  const _KatalogPage({Key? key, required this.accentColor}) : super(key: key);

  @override
  State<_KatalogPage> createState() => _KatalogPageState();
}

class _KatalogPageState extends State<_KatalogPage> with AutomaticKeepAliveClientMixin {
  late Future<List<Helm>> futureHelms;
  final String apiURL = 'https://coloria.biz.id/api/getHelm.php';

  // <-- 1. TAMBAHKAN VARIABEL UNTUK SEARCH
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = ''; // State untuk menyimpan query pencarian

  @override
  void initState() {
    super.initState();
    futureHelms = fetchHelms();
    
    // <-- 2. TAMBAHKAN LISTENER UNTUK SEARCH CONTROLLER
    // Listener ini akan memperbarui UI setiap kali teks berubah
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text;
      });
    });
  }

  // <-- 3. JANGAN LUPA DISPOSE CONTROLLER
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<List<Helm>> fetchHelms() async {
    final response = await http.get(Uri.parse(apiURL));
    if (response.statusCode == 200) {
      try {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse is Map<String, dynamic> && jsonResponse.containsKey('data')) {
          final dataList = jsonResponse['data'] as List<dynamic>;
          return dataList.map((json) => Helm.fromJson(json)).toList();
        } else {
          throw Exception('Format data API tidak valid');
        }
      } catch (e) {
        throw Exception('Gagal mengurai data: $e');
      }
    } else {
      throw Exception('Gagal memuat data helm. Status: ${response.statusCode}');
    }
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final Color accentColor = widget.accentColor; // Ambil accentColor dari widget

    // <-- 4. BUNGKUS BODY DENGAN COLUMN
    return Column(
      children: [
        // <-- 5. TAMBAHKAN SEARCH BAR (TEXTFIELD)
        Padding(
          padding: const EdgeInsets.fromLTRB(12.0, 12.0, 12.0, 8.0),
          child: TextField(
            controller: _searchController,
            style: GoogleFonts.poppins(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Cari nama helm...',
              hintStyle: GoogleFonts.poppins(color: Colors.white54),
              prefixIcon: Icon(Icons.search, color: accentColor),
              filled: true,
              fillColor: const Color(0xFF1A1A1A), // Warna card gelap
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0),
                borderSide: BorderSide(color: accentColor, width: 1.5),
              ),
            ),
          ),
        ),
        
        // <-- 6. BUNGKUS FUTUREBUILDER DENGAN EXPANDED
        Expanded(
          child: FutureBuilder<List<Helm>>(
            future: futureHelms,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(color: accentColor),
                );
              } else if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'Gagal mengambil data:\n${snapshot.error}',
                      style: GoogleFonts.poppins(color: Colors.red, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              } else if (snapshot.hasData) {
                
                // <-- 7. LOGIKA FILTER DIMASUKKAN DI SINI
                final allHelms = snapshot.data!;
                final filteredHelms = allHelms.where((helm) {
                  final helmName = helm.nama.toLowerCase();
                  final query = _searchQuery.toLowerCase();
                  return helmName.contains(query);
                }).toList();
                
                // Tampilkan pesan jika hasil filter kosong
                if (filteredHelms.isEmpty) {
                   return Center(
                    child: Text(
                      _searchQuery.isEmpty 
                        ? 'Data helm kosong.' // Jika DB kosong
                        : 'Helm tidak ditemukan.', // Jika hasil search kosong
                      style: GoogleFonts.poppins(color: accentColor),
                    ),
                  );
                }

                // <-- 8. GUNAKAN 'filteredHelms' UNTUK MEMBANGUN GRID
                return Padding(
                  padding: const EdgeInsets.fromLTRB(8.0, 0, 8.0, 8.0),
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10.0,
                      mainAxisSpacing: 10.0,
                      childAspectRatio: 0.65, 
                    ),
                    itemCount: filteredHelms.length, // Gunakan panjang list hasil filter
                    itemBuilder: (context, index) {
                      return ProductCard(helm: filteredHelms[index], accentColor: accentColor);
                    },
                  ),
                );
              } else {
                return Center(
                  child: Text(
                    'Memuat...',
                    style: GoogleFonts.poppins(color: accentColor),
                  ),
                );
              }
            },
          ),
        ),
      ],
    );
  }
}