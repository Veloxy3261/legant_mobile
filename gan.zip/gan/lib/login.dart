import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'home.dart';

enum PageMode { login, register }

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();

  final _namaController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;
  PageMode _pageMode = PageMode.login;

  final String _apiBaseUrl = 'https://coloria.biz.id/api';

  final Color primaryColor = Colors.black;
  final Color secondaryColor = const Color(0xFF333333);
  final Color accentColor = const Color(0xFFFFD700);
  final Color cardColor = const Color(0xFF1A1A1A);

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.poppins(color: Colors.white),
        ),
        backgroundColor: isError ? Colors.redAccent : Colors.green,
      ),
    );
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState == null || !_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    if (_pageMode == PageMode.login) {
      await _performLogin();
    } else {
      await _performRegister();
    }

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _performLogin() async {
    try {
      final url = Uri.parse('$_apiBaseUrl/login.php');

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': _emailController.text,
          'password': _passwordController.text,
        }),
      );

      final responseData = jsonDecode(response.body);

      if (responseData['status'] == 'success') {
        final userData = responseData['user'] as Map<String, dynamic>;
        final String userId = userData['id'].toString();
        final String userName = userData['nama'];
        final String userEmail = userData['email'];
        final String profileImage = userData['foto_profil'] ?? 'default.png';

        final SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userId', userId);
        await prefs.setString('userName', userName);
        await prefs.setString('userEmail', userEmail);
        await prefs.setString('profileImagePath', profileImage);

        _showMessage('Login berhasil!');
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomeScreen()),
          );
        }
      } else {
        _showMessage(responseData['message'] ?? 'Login gagal', isError: true);
      }
    } catch (e) {
      _showMessage('Terjadi kesalahan: ${e.toString()}', isError: true);
    }
  }

  Future<void> _performRegister() async {
    try {
      final url = Uri.parse('$_apiBaseUrl/register.php');

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'nama': _namaController.text,
          'email': _emailController.text,
          'password': _passwordController.text,
        }),
      );

      final responseData = jsonDecode(response.body);

      if (responseData['status'] == 'success') {
        _showMessage(responseData['message'] ?? 'Pendaftaran berhasil!');
        setState(() {
          _pageMode = PageMode.login;
        });
      } else {
        _showMessage(responseData['message'] ?? 'Pendaftaran gagal', isError: true);
      }
    } catch (e) {
      _showMessage('Terjadi kesalahan: ${e.toString()}', isError: true);
    }
  }

  void _togglePageMode() {
    setState(() {
      _pageMode =
          _pageMode == PageMode.login ? PageMode.register : PageMode.login;
      _formKey.currentState?.reset();
      _namaController.clear();
      _emailController.clear();
      _passwordController.clear();
    });
  }

  @override
  void dispose() {
    _namaController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isLoginMode = _pageMode == PageMode.login;
    final String title = isLoginMode ? 'Welcome Back' : 'Create Account';
    final String subtitle =
        isLoginMode ? 'Sign in to your account' : 'Sign up to get started';
    final String buttonText = isLoginMode ? 'LOGIN' : 'DAFTAR';
    final String toggleButtonText =
        isLoginMode ? 'Belum punya akun? ' : 'Sudah punya akun? ';
    final String toggleButtonActionText = isLoginMode ? 'Daftar' : 'Login';

    return Scaffold(
      backgroundColor: secondaryColor,
      appBar: AppBar(
        title: Text(
          isLoginMode ? 'Legant Login' : 'Legant Register',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700,
            color: accentColor,
          ),
        ),
        backgroundColor: primaryColor,
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                    color: accentColor,
                  ),
                ),
                Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: Colors.grey[400],
                  ),
                ),
                const SizedBox(height: 40),
                if (!isLoginMode)
                  _buildTextFormField(
                    controller: _namaController,
                    label: 'Nama Lengkap',
                    icon: Icons.badge,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Nama tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                if (!isLoginMode) const SizedBox(height: 20),
                _buildTextFormField(
                  controller: _emailController,
                  label: 'Email',
                  icon: Icons.email,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Email tidak boleh kosong';
                    }
                    if (!value.contains('@')) {
                      return 'Email tidak valid';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                _buildTextFormField(
                  controller: _passwordController,
                  label: 'Password',
                  icon: Icons.lock,
                  obscureText: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Password tidak boleh kosong';
                    }
                    if (value.length < 6) {
                      return 'Password minimal 6 karakter';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: _isLoading ? null : _submitForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.black,
                            strokeWidth: 3,
                          ),
                        )
                      : Text(
                          buttonText,
                          style: GoogleFonts.poppins(
                            color: Colors.black,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                ),
                const SizedBox(height: 20),
                TextButton(
                  onPressed: _togglePageMode,
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      text: toggleButtonText,
                      style: GoogleFonts.poppins(color: Colors.grey[400]),
                      children: [
                        TextSpan(
                          text: toggleButtonActionText,
                          style: GoogleFonts.poppins(
                            color: accentColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      validator: validator,
      keyboardType: keyboardType,
      style: GoogleFonts.poppins(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.poppins(color: Colors.grey[400]),
        prefixIcon: Icon(icon, color: accentColor),
        filled: true,
        fillColor: cardColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide(color: accentColor.withOpacity(0.5), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide(color: accentColor, width: 2),
        ),
      ),
    );
  }
}