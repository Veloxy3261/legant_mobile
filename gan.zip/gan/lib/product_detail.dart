import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'models/helm.dart';

class ProductDetailScreen extends StatelessWidget {
  final Helm helm;
  const ProductDetailScreen({super.key, required this.helm});

  static const Color primaryColor = Colors.black;
  static const Color secondaryColor = Color(0xFF333333);
  static const Color accentColor = Color(0xFFFFD700);

  final String _addToCartUrl = 'https://coloria.biz.id/api/add_to_cart.php';

  Future<void> _addToCart(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final prefs = await SharedPreferences.getInstance();
    final String? userId = prefs.getString('userId');

    if (userId == null || userId.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('Anda harus login untuk menambah item.'), backgroundColor: Colors.redAccent));
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(_addToCartUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': userId,
          'helm_id': helm.id,
          'quantity': 1,
        }),
      );

      final responseData = jsonDecode(response.body);
      if (responseData['status'] == 'success') {
        messenger.showSnackBar(SnackBar(content: Text(responseData['message'] ?? 'Berhasil ditambah')));
      } else {
        messenger.showSnackBar(SnackBar(content: Text(responseData['message'] ?? 'Gagal'), backgroundColor: Colors.redAccent));
      }
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Error: ${e.toString()}'), backgroundColor: Colors.redAccent));
    }
  }

  // helper removed; using ScaffoldMessenger directly to avoid using BuildContext across async gaps

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondaryColor,
      appBar: AppBar(
        title: Text(
          helm.nama,
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            color: accentColor,
          ),
        ),
        backgroundColor: primaryColor,
        iconTheme: const IconThemeData(color: accentColor),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Hero(
              tag: 'helm-image-${helm.id}',
              child: Image.network(
                helm.gambar,
                headers: const {'User-Agent': 'FlutterApp'},
                width: double.infinity,
                height: 300,
                fit: BoxFit.cover,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Container(
                    height: 300,
                    color: primaryColor,
                    child: Center(
                      child: CircularProgressIndicator(
                        color: accentColor,
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                loadingProgress.expectedTotalBytes!
                            : null,
                      ),
                    ),
                  );
                },
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 300,
                  color: primaryColor,
                  child: const Center(
                    child: Icon(Icons.broken_image, color: Colors.grey, size: 50),
                  ),
                ),
              ),
            ),
            _buildFadeInDetail(
              context,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      helm.nama,
                      style: GoogleFonts.poppins(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  _buildDetailRow('Harga', 'Rp ${helm.harga}', accentColor),
                  _buildDetailRow('Ukuran', helm.ukuran, Colors.white),
                  const Divider(color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                    child: Text(
                      'Deskripsi Produk',
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: accentColor,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16.0, 0, 16.0, 16.0),
                    child: Text(
                      helm.deskripsi,
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        height: 1.5,
                        color: Colors.grey[300],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16.0),
        color: primaryColor,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: accentColor,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
          ),
          onPressed: () {
            _addToCart(context);
          },
          child: Text(
            'Tambah ke Keranjang',
            style: GoogleFonts.poppins(
              color: Colors.black,
              fontWeight: FontWeight.w700,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, Color valueColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '$label:',
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.grey,
            ),
          ),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFadeInDetail(BuildContext context, Widget child) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 500),
      builder: (context, value, _) {
        return Opacity(
          opacity: value,
          child: Padding(
            padding: EdgeInsets.only(top: 10.0 * (1 - value)),
            child: child,
          ),
        );
      },
    );
  }
}