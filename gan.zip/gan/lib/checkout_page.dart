// lib/checkout_page.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:geolocator/geolocator.dart'; // <-- Package GPS

import 'models/cart_item.dart'; // <-- Impor model item
import 'map_picker_page.dart'; // <-- Impor halaman peta

class CheckoutPage extends StatefulWidget {
  final double baseTotalPriceIDR;
  final List<CartItem> cartItems; // <-- Menerima list item
  final String userId;            // <-- Menerima user ID

  const CheckoutPage({
    Key? key,
    required this.baseTotalPriceIDR,
    required this.cartItems,
    required this.userId,
  }) : super(key: key);

  // Tema
  static const Color primaryColor = Colors.black;
  static const Color secondaryColor = Color(0xFF333333);
  static const Color accentColor = Color(0xFFFFD700);
  static const Color cardColor = Color(0xFF1A1A1A);

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  // State untuk API (Sama)
  bool _isTimeLoading = true;
  String _displayedTime = "Memuat waktu...";
  String _selectedTimezoneKey = 'WIB';
  bool _isLoadingRates = true;
  String _selectedCurrency = 'IDR';
  double _displayedPrice = 0.0;
  Map<String, dynamic> _exchangeRates = {};
  final List<String> _currencies = ['IDR', 'USD', 'EUR', 'JPY', 'SGD'];
  
  // --- STATE BARU UNTUK ALAMAT & ORDER ---
  final TextEditingController _addressController = TextEditingController();
  String _shippingAddress = ""; // Alamat final yang akan dikirim
  double? _latitude;
  double? _longitude;
  bool _isGettingLocation = false; // Loading untuk GPS
  bool _isSubmittingOrder = false; // Loading untuk tombol konfirmasi

  // API Key (Sama)
  final String _timezoneDBApiKey = 'LAOWKET96A7H';
  final String _exchangeRateApiKey = 'd68c42c35e639dfee8ca5206';

  // URL API Backend Anda
  final String _createOrderUrl = 'https://coloria.biz.id/api/create_order.php';
  final String _clearCartUrl = 'https://coloria.biz.id/api/clear_cart.php';


  @override
  void initState() {
    super.initState();
    _displayedPrice = widget.baseTotalPriceIDR;
    _fetchCurrencyRates();
    _fetchTimeByZone(_timezones[_selectedTimezoneKey]!);
  }

  @override
  void dispose() {
    _addressController.dispose();
    super.dispose();
  }

  // --- FUNGSI ALAMAT BARU ---

  /// 1. Ambil lokasi GPS saat ini
  Future<void> _getCurrentLocation() async {
    setState(() {
      _isGettingLocation = true;
      _addressController.text = "Mencari lokasi GPS...";
    });

    try {
      // Cek izin
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Izin lokasi ditolak');
        }
      }
      
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Izin lokasi ditolak permanen. Buka pengaturan aplikasi.');
      } 

      // Ambil posisi
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      
      setState(() {
        _latitude = position.latitude;
        _longitude = position.longitude;
        _addressController.text = "Mendapatkan alamat dari GPS...";
      });

      // Konversi koordinat ke alamat pakai Nominatim (OSM)
      await _getAddressFromCoordinates(position.latitude, position.longitude);

    } catch (e) {
      _showMessage(e.toString(), isError: true);
      _addressController.clear();
    } finally {
      setState(() {
        _isGettingLocation = false;
      });
    }
  }

  /// 2. Konversi Koordinat ke Alamat (Nominatim)
  Future<void> _getAddressFromCoordinates(double lat, double lon) async {
    try {
      final url = Uri.parse('https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lon&accept-language=id');
      final response = await http.get(url, headers: {'User-Agent': 'FlutterApp/1.0 (tonnnz.project)'});

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final address = data['display_name'] ?? 'Alamat tidak ditemukan';
        setState(() {
          _shippingAddress = address;
          _addressController.text = address;
        });
      } else {
        throw Exception('Gagal memuat alamat');
      }
    } catch (e) {
      _showMessage(e.toString(), isError: true);
    }
  }

  /// 3. Buka Halaman Peta
  Future<void> _openMapPicker() async {
    // Navigasi ke halaman peta dan tunggu hasilnya
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const MapPickerPage()),
    );

    // Jika user memilih lokasi dan kembali
    if (result != null && result is Map) {
      setState(() {
        _shippingAddress = result['address'];
        _addressController.text = result['address'];
        _latitude = result['lat'];
        _longitude = result['lng'];
      });
    }
  }

  /// 4. Submit Pesanan ke Backend
  Future<void> _submitOrder() async {
    // Validasi
    if (_addressController.text.isEmpty) {
      _showMessage('Alamat pengiriman wajib diisi.', isError: true);
      return;
    }
    // Jika user hanya mengetik manual, simpan teksnya
    if (_shippingAddress.isEmpty) {
      _shippingAddress = _addressController.text;
    }

    setState(() {
      _isSubmittingOrder = true;
    });

    try {
      // 1. Siapkan data item untuk JSON
      List<Map<String, dynamic>> itemsForJson = widget.cartItems.map((item) {
        return {
          'helm_id': item.helmId,
          'quantity': item.quantity,
          // Konversi harga '330.000' ke integer 330000
          'price': int.tryParse(item.harga.replaceAll('.', '')) ?? 0, 
        };
      }).toList();

      // 2. Kirim pesanan ke 'create_order.php'
      final responseOrder = await http.post(
        Uri.parse(_createOrderUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': int.tryParse(widget.userId),
          'shipping_address': _shippingAddress,
          'lat': _latitude, // Bisa null jika hanya input manual
          'lng': _longitude, // Bisa null jika hanya input manual
          'total_price': widget.baseTotalPriceIDR.toInt(),
          'currency': _selectedCurrency,
          'items': itemsForJson, // Kirim list item
        }),
      );

      final dataOrder = json.decode(responseOrder.body);

      if (dataOrder['status'] == 'success') {
        // 3. Jika Pesanan sukses, kosongkan keranjang
        await _clearCart();
        
        _showMessage('Pesanan berhasil dibuat!');
        
        // 4. Kembali ke cart_screen dengan sinyal sukses
        if (mounted) {
          Navigator.pop(context, 'checkout_success');
        }
      } else {
        throw Exception(dataOrder['message'] ?? 'Gagal membuat pesanan');
      }

    } catch (e) {
      _showMessage(e.toString(), isError: true);
    } finally {
      setState(() {
        _isSubmittingOrder = false;
      });
    }
  }

  /// 5. Panggil API untuk kosongkan keranjang
  Future<void> _clearCart() async {
    try {
      await http.post(
        Uri.parse(_clearCartUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': int.tryParse(widget.userId),
        }),
      );
      // Kita tidak perlu cek respons, "fire and forget"
    } catch (e) {
      // Jangan tampilkan error jika gagal clear cart,
      // karena pesanan sudah berhasil dibuat.
      print("Gagal clear cart: $e");
    }
  }


  // --- FUNGSI API LAMA (Tidak Berubah) ---
  final Map<String, String> _timezones = {
    'WIB': 'Asia/Jakarta', 'WITA': 'Asia/Makassar', 'WIT': 'Asia/Jayapura', 'London': 'Europe/London', 'Tokyo': 'Asia/Tokyo',
  };
  
  Future<void> _fetchTimeByZone(String zoneName) async {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    setState(() { _isTimeLoading = true; });
    try {
      final url = Uri.parse('http://api.timezonedb.com/v2.1/get-time-zone?key=$_timezoneDBApiKey&format=json&by=zone&zone=$zoneName');
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'OK') {
          String rawTimestamp = data['formatted'];
          DateTime parsedTime = DateTime.parse(rawTimestamp);
          setState(() {
            _displayedTime = DateFormat('d MMM yyyy, HH:mm', 'id_ID').format(parsedTime);
            _isTimeLoading = false;
          });
        } else { throw Exception(data['message']); }
      } else { throw Exception('Gagal terhubung ke TimezoneDB'); }
    } catch (e) {
      if (mounted) { setState(() { _displayedTime = "Gagal memuat waktu"; _isTimeLoading = false; }); _showMessage(e.toString(), isError: true); }
    }
  }
  
  Future<void> _fetchCurrencyRates() async {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    setState(() { _isLoadingRates = true; });
    try {
      final url = 'https://v6.exchangerate-api.com/v6/$_exchangeRateApiKey/latest/IDR';
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.containsKey('conversion_rates')) { _exchangeRates = data['conversion_rates']; }
        else if (data.containsKey('rates')) { _exchangeRates = data['rates']; }
        setState(() { _isLoadingRates = false; });
      } else { throw Exception('Gagal memuat kurs mata uang'); }
    } catch (e) {
      if (mounted) { setState(() { _isLoadingRates = false; }); _showMessage('Error memuat kurs: ${e.toString()}', isError: true); }
    }
  }
  
  void _showMessage(String message, {bool isError = false}) {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.poppins(color: isError ? Colors.white : Colors.black,)),
        backgroundColor: isError ? Colors.redAccent : CheckoutPage.accentColor,
      ),
    );
  }
  
  void _convertTimezone(String? zoneKey) {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    if (zoneKey == null || !_timezones.containsKey(zoneKey)) return;
    final newZoneName = _timezones[zoneKey]!;
    setState(() { _selectedTimezoneKey = zoneKey; });
    _fetchTimeByZone(newZoneName);
  }

  void _convertCurrency(String? newCurrency) {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    if (newCurrency == null || _exchangeRates.isEmpty) return;
    final rate = _exchangeRates[newCurrency] as num;
    setState(() {
      _selectedCurrency = newCurrency;
      _displayedPrice = widget.baseTotalPriceIDR * rate.toDouble();
    });
  }
  
  String _formatCurrency(double price, String currencyCode) {
    // ... (Kode SAMA PERSIS seperti sebelumnya) ...
    String locale = 'id_ID'; String symbol = 'Rp ';
    switch (currencyCode) {
      case 'USD': locale = 'en_US'; symbol = '\$'; break;
      case 'EUR': locale = 'de_DE'; symbol = '€'; break;
      case 'JPY': locale = 'ja_JP'; symbol = '¥'; break;
      case 'SGD': locale = 'en_SG'; symbol = 'S\$'; break;
    }
    return NumberFormat.currency(
      locale: locale, symbol: symbol,
      decimalDigits: (currencyCode == 'JPY' || currencyCode == 'IDR') ? 0 : 2,
    ).format(price);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CheckoutPage.secondaryColor,
      appBar: AppBar(
        title: Text('Konfirmasi Checkout', style: GoogleFonts.poppins(fontWeight: FontWeight.w700, color: CheckoutPage.accentColor)),
        backgroundColor: CheckoutPage.primaryColor,
        iconTheme: const IconThemeData(color: CheckoutPage.accentColor),
      ),
      body: (_isLoadingRates)
          ? Center(child: CircularProgressIndicator(color: CheckoutPage.accentColor))
          : Column( // Ubah ke Column agar tombol tidak ter-scroll
              children: [
                Expanded(
                  // Buat konten bisa di-scroll
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        // --- KONTEN NOTA ---
                        Container(
                          padding: const EdgeInsets.all(20.0),
                          decoration: BoxDecoration(
                            color: CheckoutPage.cardColor,
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: CheckoutPage.accentColor.withAlpha((0.5 * 255).round()), width: 1),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Text('NOTA PESANAN', style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.w700, color: CheckoutPage.accentColor)),
                              ),
                              const SizedBox(height: 10),
                              Divider(color: CheckoutPage.secondaryColor, thickness: 2),
                              _buildSectionHeader('Alamat Pengiriman'),
                              TextField(
                                controller: _addressController,
                                style: GoogleFonts.poppins(color: Colors.white),
                                decoration: InputDecoration(
                                  hintText: 'Masukkan alamat lengkap...',
                                  hintStyle: GoogleFonts.poppins(color: Colors.white54),
                                  filled: true,
                                  fillColor: CheckoutPage.secondaryColor,
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                                ),
                                maxLines: 3,
                                onChanged: (value) {
                                  // Jika user mengetik manual, hapus koordinat
                                  setState(() {
                                    _shippingAddress = value;
                                    _latitude = null;
                                    _longitude = null;
                                  });
                                },
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      icon: _isGettingLocation ? SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2, color: CheckoutPage.accentColor)) : Icon(Icons.my_location, size: 16),
                                      label: Text('Lokasi Saat Ini'),
                                      style: OutlinedButton.styleFrom(foregroundColor: CheckoutPage.accentColor, side: BorderSide(color: CheckoutPage.accentColor)),
                                      onPressed: _isGettingLocation ? null : _getCurrentLocation,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      icon: Icon(Icons.map, size: 16),
                                      label: Text('Pilih dari Peta'),
                                      style: OutlinedButton.styleFrom(foregroundColor: CheckoutPage.accentColor, side: BorderSide(color: CheckoutPage.accentColor)),
                                      onPressed: _openMapPicker,
                                    ),
                                  ),
                                ],
                              ),
                              // --- AKHIR BAGIAN ALAMAT ---

                              Divider(color: CheckoutPage.secondaryColor, thickness: 2, height: 30),
                              
                              _buildSectionHeader('Waktu Checkout'),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  _isTimeLoading 
                                    ? Padding(padding: const EdgeInsets.symmetric(vertical: 10.0), child: SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: CheckoutPage.accentColor, strokeWidth: 2,)))
                                    : Text(_displayedTime, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white)),
                                  _buildDropdown(
                                    value: _selectedTimezoneKey,
                                    items: _timezones.keys.toList(),
                                    onChanged: _convertTimezone,
                                  ),
                                ],
                              ),

                              const SizedBox(height: 24),
                              
                              _buildSectionHeader('Total Harga'),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Text(
                                      _formatCurrency(_displayedPrice, _selectedCurrency),
                                      style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.bold, color: CheckoutPage.accentColor),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  _buildDropdown(
                                    value: _selectedCurrency,
                                    items: _currencies,
                                    onChanged: _convertCurrency,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                // --- TOMBOL KONFIRMASI (PINDAH KE LUAR) ---
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: CheckoutPage.accentColor,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                      ),
                      onPressed: _isSubmittingOrder ? null : _submitOrder,
                      child: _isSubmittingOrder
                        ? SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.black))
                        : Text(
                            'Konfirmasi & Buat Pesanan',
                            style: GoogleFonts.poppins(color: Colors.black, fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                    ),
                  ),
                )
              ],
            ),
    );
  }

  // --- Widget Helper (Tidak Berubah) ---
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.white70, fontSize: 12),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      decoration: BoxDecoration(
        color: CheckoutPage.secondaryColor,
        borderRadius: BorderRadius.circular(8),
  border: Border.all(color: CheckoutPage.accentColor.withAlpha((0.5 * 255).round()))
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          dropdownColor: CheckoutPage.cardColor,
          style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w500),
          items: items.map((String key) {
            return DropdownMenuItem<String>(value: key, child: Text(key));
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}