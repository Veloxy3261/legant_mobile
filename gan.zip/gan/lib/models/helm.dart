// lib/models/helm.dart

class Helm {
  final String id;
  final String nama;
  final String harga;
  final String ukuran;
  final String deskripsi;
  final String gambar; // Sudah berupa URL lengkap dari PHP

  const Helm({
    required this.id,
    required this.nama,
    required this.harga,
    required this.ukuran,
    required this.deskripsi,
    required this.gambar,
  });

  factory Helm.fromJson(Map<String, dynamic> json) {
    
    // 1. Mengambil nama dari 'nama_helm' (sesuai DB)
    final rawNama = json['nama_helm']?.toString() ?? 'Nama Tidak Ada'; 
    
    // 2. Mengambil URL gambar LANGSUNG (PHP sudah menggabungkan Base URL)
    final fullImageUrl = json['gambar']?.toString() ?? 'https://via.placeholder.com/150'; 

    return Helm(
      id: json['id']?.toString() ?? '',
      nama: rawNama, 
      // Menggunakan .toString() untuk mengatasi error int is not a subtype of String
      harga: json['harga']?.toString() ?? '0', 
      ukuran: json['ukuran']?.toString() ?? 'S-XL', 
      deskripsi: json['deskripsi']?.toString() ?? 'Tidak ada deskripsi.',
      gambar: fullImageUrl, 
    );
  }
}