// lib/models/cart_item.dart

class CartItem {
  final String cartId;
  final String helmId;
  final String namaHelm;
  final String harga;
  final String gambar;
  final int quantity;

  CartItem({
    required this.cartId,
    required this.helmId,
    required this.namaHelm,
    required this.harga,
    required this.gambar,
    required this.quantity,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) {
    return CartItem(
      cartId: json['cart_id'].toString(),
      helmId: json['helm_id'].toString(),
      namaHelm: json['nama_helm'] ?? 'Nama Tidak Ada',
      harga: json['harga']?.toString() ?? '0',
      gambar: json['gambar'] ?? '',
      quantity: (json['quantity'] is int) ? json['quantity'] : int.tryParse(json['quantity'].toString()) ?? 1,
    );
  }
}