// lib/company_profile_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CompanyProfileScreen extends StatefulWidget {
  const CompanyProfileScreen({super.key});

  @override
  State<CompanyProfileScreen> createState() => _CompanyProfileScreenState();
}

class _CompanyProfileScreenState extends State<CompanyProfileScreen> {
  final PageController _pageController = PageController();
  Timer? _timer;

  final List<String> _images = [
    'assets/logo.png',
    'assets/logo2.jpeg',
    'assets/logo3.jpeg',
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (!_pageController.hasClients) return;
      final next = (_pageController.page ?? 0).round() + 1;
      _pageController.animateToPage(
        next % _images.length,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  // Definisi Skema Warna
  static const Color primaryColor = Colors.black;
  static const Color secondaryColor = Color(0xFF333333);
  static const Color accentColor = Color(0xFFFFD700);
  static const Color cardColor = Color(0xFF1A1A1A);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondaryColor,
      appBar: AppBar(
        title: Text(
          'Tentang Legant',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700,
            color: accentColor,
          ),
        ),
        backgroundColor: primaryColor,
        iconTheme: const IconThemeData(color: accentColor),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Carousel: three images that auto-scroll
            SizedBox(
              height: 180,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: _images.length,
                  itemBuilder: (context, index) {
                    return Image.asset(
                      _images[index],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.black12,
                        child: Center(
                          child: Icon(Icons.broken_image, color: accentColor, size: 48),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Legant Helmet',
              style: GoogleFonts.poppins(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: accentColor,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'OBAT KALCERMU DI JALAN.',
              style: GoogleFonts.poppins(
                fontSize: 18,
                color: Colors.white70,
              ),
            ),
            Divider(color: cardColor, height: 40, thickness: 2),
            
            _buildSectionTitle('Visi Kami'),
            _buildSectionText(
              'Menjadi merek helm premium terkemuka di Indonesia yang memadukan desain vintage elegan dengan teknologi keamanan terkini.',
            ),
            
            const SizedBox(height: 20),
            
            _buildSectionTitle('Informasi Kontak'),
            _buildInfoRow(Icons.email, 'Email', 'info@legant-helmet.com'),
            _buildInfoRow(Icons.phone, 'Telepon', '+62 21 8888 7777'),
            _buildInfoRow(Icons.camera_alt, 'Instagram', '@legant_helmet'),
            _buildInfoRow(Icons.location_on, 'Alamat Pusat', 'Bantul Yogyakarta, Indonesia'),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: 22,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildSectionText(String text) {
    return Text(
      text,
      textAlign: TextAlign.justify,
      style: GoogleFonts.poppins(
        fontSize: 15,
        color: Colors.white54,
        height: 1.5,
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: accentColor, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.poppins(color: Colors.white70, fontWeight: FontWeight.w500, fontSize: 14),
                ),
                Text(
                  value,
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}