import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  String _userName = 'Memuat...';
  String _userEmail = 'Memuat...';
  String _userId = '';
  String _profileImagePath = 'default.png';
  bool _isLoading = true;
  String _cacheBuster = ''; // Perbaikan: Untuk cache-busting efisien

  static const Color primaryColor = Colors.black;
  static const Color secondaryColor = Color(0xFF333333);
  static const Color accentColor = Color(0xFFFFD700);
  static const Color cardColor = Color(0xFF1A1A1A);

  final String _uploadApiUrl = 'https://coloria.biz.id/api/upload_profile.php';
  final String _baseImageUrl = 'https://coloria.biz.id/images/profile/';

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  Future<void> _loadUserProfile() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    final String? id = prefs.getString('userId');
    final String? name = prefs.getString('userName');
    final String? email = prefs.getString('userEmail');
    final String? photoPath = prefs.getString('profileImagePath');

    if (mounted) {
      setState(() {
        _userId = id ?? '';
        _userName = name ?? 'Tidak Ada Nama';
        _userEmail = email ?? 'Tidak Ada Email';
        _profileImagePath = photoPath ?? 'default.png';
        _isLoading = false;
        _cacheBuster = DateTime.now().millisecondsSinceEpoch.toString();
      });
    }
  }

  Future<void> _pickAndUploadImage() async {
    if (_userId.isEmpty) {
      _showMessage('Gagal: User ID tidak ditemukan. Silakan login ulang.',
          isError: true);
      return;
    }

    final picker = ImagePicker();
    XFile? pickedFile;

    await showModalBottomSheet(
      context: context,
      backgroundColor: primaryColor,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.photo_camera, color: accentColor),
                title: Text('Kamera',
                    style: GoogleFonts.poppins(color: Colors.white)),
                onTap: () async {
                  Navigator.pop(context);
                  pickedFile =
                      await picker.pickImage(source: ImageSource.camera);
                  if (pickedFile != null) {
                    await _processAndUpload(pickedFile!);
                  }
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library, color: accentColor),
                title: Text('Galeri',
                    style: GoogleFonts.poppins(color: Colors.white)),
                onTap: () async {
                  Navigator.pop(context);
                  pickedFile =
                      await picker.pickImage(source: ImageSource.gallery);
                  if (pickedFile != null) {
                    await _processAndUpload(pickedFile!);
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _processAndUpload(XFile pickedFile) async {
    File imageFile = File(pickedFile.path);
    setState(() {
      _isLoading = true;
    });
    await _uploadImage(imageFile);
  }

  Future<void> _uploadImage(File file) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var request = http.MultipartRequest('POST', Uri.parse(_uploadApiUrl));

      request.fields['user_id'] = _userId;

      request.files.add(
        await http.MultipartFile.fromPath(
          'foto_profil',
          file.path,
        ),
      );

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData['status'] == 'success') {
          final newPath = responseData['file_path'] as String;

          await prefs.setString('profileImagePath', newPath);

          setState(() {
            _profileImagePath = newPath;
            _cacheBuster = DateTime.now().millisecondsSinceEpoch.toString();
          });
          _showMessage('Foto profil berhasil diunggah!');
        } else {
          _showMessage('Upload gagal: ${responseData['message']}', isError: true);
        }
      } else {
        _showMessage('Gagal terhubung ke server. Status: ${response.statusCode}',
            isError: true);
      }
    } catch (e) {
      _showMessage('Terjadi kesalahan saat upload: ${e.toString()}',
          isError: true);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.redAccent : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final String fullImageUrl = '$_baseImageUrl$_profileImagePath?t=$_cacheBuster';

    return Scaffold(
      backgroundColor: secondaryColor,
      appBar: AppBar(
        title: Text(
          'Profil Pengguna',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700,
            color: accentColor,
          ),
        ),
        backgroundColor: primaryColor,
        iconTheme: const IconThemeData(color: accentColor),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: accentColor))
          : SingleChildScrollView(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundColor: accentColor,
                            backgroundImage: NetworkImage(fullImageUrl),
                            child: _profileImagePath == 'default.png'
                                ? Icon(Icons.account_circle,
                                    size: 90, color: primaryColor)
                                : null,
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: InkWell(
                              onTap: _pickAndUploadImage,
                              child: CircleAvatar(
                                radius: 18,
                                backgroundColor: accentColor,
                                child: Icon(Icons.camera_alt,
                                    size: 18, color: primaryColor),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      // Bordered card now menampilkan username dan email (telepon & alamat dihapus)
                      const SizedBox(height: 10),
                      Card(
                        color: cardColor,
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Username dengan border style yang sama
                              Row(
                                children: [
                                  Icon(Icons.person, color: accentColor, size: 20),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Username',
                                          style: GoogleFonts.poppins(
                                              color: Colors.white70, fontWeight: FontWeight.w500),
                                        ),
                                        Text(
                                          _userName,
                                          style: GoogleFonts.poppins(
                                              color: Colors.white, fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const Divider(color: secondaryColor, height: 20),
                              // Email
                              Row(
                                children: [
                                  Icon(Icons.email, color: accentColor, size: 20),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Email',
                                          style: GoogleFonts.poppins(
                                              color: Colors.white70, fontWeight: FontWeight.w500),
                                        ),
                                        Text(
                                          _userEmail,
                                          style: GoogleFonts.poppins(
                                              color: Colors.white, fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  // ...existing code...
}