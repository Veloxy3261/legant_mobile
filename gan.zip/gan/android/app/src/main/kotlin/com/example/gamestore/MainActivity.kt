package com.example.gamestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
